package memorymgmt;


public class Test {

	public static void main(String[] args) {
		int i = 100;
		SavingsAccount account = new SavingsAccount(100,5000,1234);
		account.withdrawAmount(1000);
		
		System.out.println("End of main()");
		System.gc();

	}

}
