package memorymgmt;

public class TestFileProcessor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     FileProcessor fileprocessor = new FileProcessor("/Users/Owner/Desktop/sample.txt");
	//fileprocessor.processData();
     
     fileprocessor = null;
     System.gc();
	
	}

}
